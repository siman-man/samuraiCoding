g++ *.cpp
