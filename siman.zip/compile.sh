g++ -O2 *.cpp
