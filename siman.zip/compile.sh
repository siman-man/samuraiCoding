g++ -O0 *.cpp
